package com.carrot.carrotblog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarrotBlogApplicationTests {

    @Test
    void contextLoads() {
    }

}
