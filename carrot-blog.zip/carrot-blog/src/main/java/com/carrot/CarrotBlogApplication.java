package com.carrot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author Carrot
 */
@SpringBootApplication
public class CarrotBlogApplication {


    public static void main(String[] args) {
        SpringApplication.run(CarrotBlogApplication.class, args);
    }

}
