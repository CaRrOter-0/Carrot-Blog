package com.carrot.entity;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * 博客实体类
 *
 * @author Carrot
 * @create 2022/1/19 - 20:05
 */
@Data
@NoArgsConstructor
@ToString
public class Blog {

    private Long id;
    private String title;
    private String firstPicture;
    private String flag;
    private Integer views;
    private boolean appreciation;
    private boolean shareStatement;
    private boolean commentabled;
    private boolean published;
    private boolean recommend;
    private Date createTime;
    private Date updateTime;
    private String content;
    private String description;

    private Long typeId;
    private Long userId;
    private Type type;
    private User user;

    private List<Comment> comments = new ArrayList<>();
}


