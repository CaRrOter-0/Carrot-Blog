package com.carrot.entity;

import com.carrot.vo.DetailedBlog;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * bug找出来了，nickname后台没获取到是因为在Comment实体类中，
 * 自动调用setter,getter时候，getnickName(String nickName)参数自动用了驼峰命名
 *
 * @author Carrot
 * @create 2022/1/20 - 12:16
 */
@Data
@NoArgsConstructor
@ToString
public class Comment {

    private Long id;
    private String nickname;
    private String email;
    private String content;

    private String avatar;
    private Date createTime;

    private Long blogId;
    private DetailedBlog blog;

    /*一个父对象有好多个子对象，因此用list*/
    private List<Comment> replyComments = new ArrayList<>();

    /*一个评论对象可能有它的父对象*/
    private Long parentCommentId;
    private Comment parentComment;
    private String parentNickname;

    private boolean adminComment;

}
