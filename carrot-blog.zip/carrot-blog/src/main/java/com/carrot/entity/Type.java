package com.carrot.entity;

import lombok.*;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Carrot
 * @create 2022/1/20 - 12:11
 */
@Data
@NoArgsConstructor
@ToString
public class Type {

    private Long id;
    private String name;

    private List<Blog> blogs = new ArrayList<>();

}
