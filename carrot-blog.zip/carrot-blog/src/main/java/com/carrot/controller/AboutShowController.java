package com.carrot.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

/**
 * @author Carrot
 * @create 2022/3/3 - 18:11
 */
@Controller
public class AboutShowController {

    @GetMapping("/about")
    public String about(Model model) {
        return "about";
    }
}
