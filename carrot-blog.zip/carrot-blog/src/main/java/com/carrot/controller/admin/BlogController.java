package com.carrot.controller.admin;

import com.carrot.entity.Blog;
import com.carrot.entity.Type;
import com.carrot.entity.User;
import com.carrot.service.BlogService;
import com.carrot.service.TypeService;
import com.carrot.vo.BlogQuery;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpSession;
import java.util.List;

/**
 * @author Carrot
 * @create 2022/1/21 - 17:02
 */
@Controller
@RequestMapping("/admin")
public class BlogController {

    @Autowired
    private BlogService blogService;
    @Autowired
    private TypeService typeService;

    /**
     * 跳转博客新增
     * @param model
     * @return
     */
    @GetMapping("/blogs/input")
    public String input(Model model) {
        model.addAttribute("types", typeService.listAllType());
        model.addAttribute("blog", new Blog());
        return "admin/blogs-input";
    }

    /**
     * 跳转编辑修改文章
      * @param id
     * @param model
     * @return
     */
    @GetMapping("/blogs/{id}/input")
    public String editInput(@PathVariable Long id, Model model) {
        model.addAttribute("blog", blogService.getBlog(id));
        model.addAttribute("types", typeService.listAllType());
        return "admin/blogs-input";
    }

    /**
     * 新增博客
     * @param blog
     * @param attributes
     * @param session
     * @return
     */
    @PostMapping("/blogs")
    public String post(Blog blog, RedirectAttributes attributes, HttpSession session) {
        //新增的时候需要传递blog对象，blog对象需要有user
        blog.setUser((User) session.getAttribute("user"));
        blog.setUserId(blog.getUser().getId());
        //设置blog的type
        blog.setType(typeService.getType(blog.getType().getId()));

        int b = blogService.saveBlog(blog);

        if (b == 0) {
            attributes.addFlashAttribute("message", "新增失败");
        } else {
            attributes.addFlashAttribute("message", "新增成功");
        }

        return "redirect:/admin/blogs";
    }

    @GetMapping("/blogs/{id}/delete")
    public String deletePost(Blog blog, RedirectAttributes attributes) {
        int b = blogService.deleteBlog(blog.getId());
        if (b == 0) {
            attributes.addFlashAttribute("message", "删除失败");
        } else {
            attributes.addFlashAttribute("message", "删除成功");
        }
        return "redirect:/admin/blogs";
    }

    /**
     * 编辑修改文章
     * @param blog
     * @param attributes
     * @return
     */
    @PostMapping("/blogs/{id}")
    public String editPost(Blog blog, RedirectAttributes attributes) {
        int b = blogService.updateBlog(blog);
        if(b ==0){
            attributes.addFlashAttribute("message", "修改失败");
        }else {
            attributes.addFlashAttribute("message", "修改成功");
        }
        return "redirect:/admin/blogs";
    }



    /**
     * 博客列表
     */
    @RequestMapping("/blogs")
    public String blogs(Model model, @RequestParam(defaultValue = "1", value = "pageNum") Integer pageNum) {

        String orderBy = "update_time desc";

        PageHelper.startPage(pageNum, 5, orderBy);
        List<Blog> blogList = blogService.listBlog();
        PageInfo<Blog> pageInfo = new PageInfo<>(blogList);

        model.addAttribute("pageInfo", pageInfo);
        model.addAttribute("types", typeService.listAllType());
        return "admin/blogs";
    }

    /**
     * 搜索博客
     * @param model
     * @param pageNum
     * @param blogQuery
     * @return
     */
    @PostMapping("/blogs/search")
    public String search(Model model, @RequestParam(defaultValue = "1", value = "pageNum") Integer pageNum, BlogQuery blogQuery) {
        String orderBy = "update_time desc";

        PageHelper.startPage(pageNum, 5, orderBy);
        List<BlogQuery> blogList = blogService.getBlogBySearch(blogQuery);
        PageInfo<BlogQuery> pageInfo = new PageInfo<>(blogList);

        model.addAttribute("pageInfo", pageInfo);
        model.addAttribute("types", typeService.listAllType());
        return "admin/blogs :: blogList";
    }

}
