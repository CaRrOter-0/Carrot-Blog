package com.carrot.controller;

import com.carrot.entity.Blog;
import com.carrot.service.BlogService;
import com.carrot.vo.BlogQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

/**
 * @author Carrot
 * @create 2022/3/2 - 18:01
 */
@Controller
public class AchieveShowController {
    //
    @Autowired
    private BlogService blogService;

    @GetMapping("/archives")
    public String achieve(Model model) {
        List<BlogQuery> blogs = blogService.getAllBlogQuery();
        model.addAttribute("blogs", blogs);
        return "archives";
    }
}
