package com.carrot.controller;

import com.carrot.NotFoundException;
import com.carrot.entity.Blog;
import com.carrot.entity.Comment;
import com.carrot.service.BlogService;
import com.carrot.service.CommentService;
import com.carrot.service.TypeService;
import com.carrot.vo.FirstPageBlog;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

/**
 * @author Carrot
 * @create 2022/1/18 - 20:22
 */
@Controller
public class IndexController {

    @Autowired
    private BlogService blogService;
    @Autowired
    private TypeService typeService;
    @Autowired
    private CommentService commentService;

    /**
     * 如果把注释去掉，9/0明显是错误的，
     * 这个时候springboot会自动拦截这个错误，
     * 并将页面自动跳转到templates/error/500.html上
     * <p>
     * 如果没有错误，springboot将跳转到index.html上
     *
     * @return
     */
    @GetMapping("/")
    public String index(Model model, @RequestParam(defaultValue = "1", value = "pageNum") Integer pageNum) {
        String orderBy = "update_time desc";

        PageHelper.startPage(pageNum, 5, orderBy);
        List<FirstPageBlog> blogList = blogService.listFirstPageBlog();
        PageInfo<FirstPageBlog> pageInfo = new PageInfo<>(blogList);

        model.addAttribute("pageInfo", pageInfo);
        model.addAttribute("types", typeService.listAllBlogByType());
        model.addAttribute("recommendedBlogs", blogService.getRecommendedBlogs());

        return "index";
    }

    @PostMapping("/search")
    public String search(Model model, @RequestParam String query,
                         @RequestParam(defaultValue = "1", value = "pageNum") Integer pageNum) {
        PageHelper.startPage(pageNum, 5);
        List<FirstPageBlog> blogList = blogService.getAllBlogsByQuery(query);
        PageInfo<FirstPageBlog> pageInfo = new PageInfo<>(blogList);

        model.addAttribute("pageInfo", pageInfo);
        model.addAttribute("query", query);
        return "search";
    }

    @GetMapping("/blog/{id}")
    public String blog(@PathVariable Long id, Model model) {
        List<Comment> comments = commentService.listCommentByBlogId(id);
        model.addAttribute("blog", blogService.getDetailedBlogById(id));
        model.addAttribute("comments", comments);
        return "blog";
    }

}

