package com.carrot.controller.admin;

import com.carrot.entity.User;
import com.carrot.service.UserService;
import com.carrot.util.MD5Utils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import javax.servlet.http.HttpSession;

/**
 * @author Carrot
 * @create 2022/1/20 - 15:28
 */
@Controller
@RequestMapping("/admin")
public class LoginController {

    @Autowired
    UserService userService;

    @GetMapping
    public String loginPage() {
        return "admin/login";
    }

    @PostMapping("/login")
    public String login(@RequestParam String username,
                                @RequestParam String password,
                                HttpSession session,
                                RedirectAttributes attributes) {
        User user = userService.checkUser(username, MD5Utils.code(password));
        if (user != null) {
            //不让密码信息传递到前端页面上
            user.setPassword(null);
            session.setAttribute("user", user);
            return "admin/index";
        } else {
            System.out.println(1);
            attributes.addFlashAttribute("message", "用户名或密码错误");
            // redirect:为重定向，不能使用model
            // 因为Model存放的是在请求域中，重定向之后是另外一个请求，所以拿不到信息
            return "redirect:/admin";
        }
    }

    @GetMapping("/logout")
    public String logOut(HttpSession session) {
        session.removeAttribute("user");
        return "redirect:/admin";
    }

}
