package com.carrot.service;

import com.carrot.entity.User;
import org.springframework.stereotype.Service;

/**
 * @author Carrot
 * @create 2022/1/20 - 15:15
 */
public interface UserService {

    User checkUser(String username, String password);
}
