package com.carrot.service;

import com.carrot.entity.Blog;
import com.carrot.vo.BlogQuery;
import com.carrot.vo.DetailedBlog;
import com.carrot.vo.FirstPageBlog;

import java.util.List;

/**
 * @author Carrot
 * @create 2022/1/23 - 17:02
 */
public interface BlogService {

    Blog getBlog(Long id);

    DetailedBlog getDetailedBlogById(Long id);

    List<Blog> listBlog();

    List<BlogQuery> getAllBlogQuery();

    List<FirstPageBlog> listFirstPageBlog();

    List<FirstPageBlog> getFirstPageBlogByTypeId(Long typeId);

    List<BlogQuery> getBlogBySearch(BlogQuery blogQuery);

    int saveBlog(Blog blog);

    int updateBlog(Blog blog);

    int deleteBlog(Long id);

    List<Blog> getRecommendedBlogs();

    List<FirstPageBlog> getAllBlogsByQuery(String query);

}
