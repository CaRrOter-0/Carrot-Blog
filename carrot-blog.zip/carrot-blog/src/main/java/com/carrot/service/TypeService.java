package com.carrot.service;

import com.carrot.entity.Type;
import com.carrot.vo.TopType;

import java.util.List;

/**
 * @author Carrot
 * @create 2022/1/22 - 13:20
 */
public interface TypeService {

    int saveType(Type type);

    Type getType(Long id);

    List<Type> listAllType();

    List<TopType> listAllBlogByType();

    int updateType(Type type);

    void deleteType(Long id);

    Type getTypeByName(String name);
}
