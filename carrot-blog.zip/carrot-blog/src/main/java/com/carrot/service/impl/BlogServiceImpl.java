package com.carrot.service.impl;

import com.carrot.NotFoundException;
import com.carrot.dao.BlogDao;
import com.carrot.entity.Blog;
import com.carrot.service.BlogService;
import com.carrot.util.MarkdownUtils;
import com.carrot.util.MyBeanUtils;
import com.carrot.vo.BlogQuery;
import com.carrot.vo.DetailedBlog;
import com.carrot.vo.FirstPageBlog;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;

/**
 * @author Carrot
 * @create 2022/1/23 - 17:10
 */
@Service
public class BlogServiceImpl implements BlogService {

    @Autowired
    private BlogDao blogDao;

    @Override
    public Blog getBlog(Long id) {
        return blogDao.getBlog(id);
    }

    @Override
    public DetailedBlog getDetailedBlogById(Long id) {
        DetailedBlog detailedBlogById = blogDao.getDetailedBlogById(id);
        if (detailedBlogById == null) {
            throw new NotFoundException("该博客不存在");
        }
        //将markdown格式的博客内容转化为html格式
        String content = detailedBlogById.getContent();
        detailedBlogById.setContent(MarkdownUtils.markdownToHtmlExtensions(content));
        // 文章访问数量自增
        blogDao.updateViews(id);
        return detailedBlogById;
    }

    @Override
    public List<Blog> listBlog() {
        return blogDao.listBlog();
    }

    @Override
    public List<BlogQuery> getAllBlogQuery() {
        return blogDao.getAllBlogQuery();
    }

    @Override
    public List<FirstPageBlog> listFirstPageBlog() {
        return blogDao.listFirstPageBlog();
    }

    @Override
    public List<FirstPageBlog> getFirstPageBlogByTypeId(Long typeId) {
        return blogDao.getFirstPageBlogByTypeId(typeId);
    }

    @Override
    public List<BlogQuery> getBlogBySearch(BlogQuery blog) {
        return blogDao.getAllBlogBySearch(blog);
    }

    @Override
    public int saveBlog(Blog blog) {
        blog.setCreateTime(new Date());
        blog.setViews(0);
        blog.setUpdateTime(new Date());
        return blogDao.saveBlog(blog);
    }

    @Override
    public int updateBlog(Blog blog) {
//        /*
//         * 由于前端传进来的blog对象的createTime和views属性为空，
//         * 我们可以先找出原先对应id的blog对象
//         * 然后通过BeanUtils.copyProperties()方法，
//         * 将前端传入的blog对象的修改数据copy到原先对应id的blog对象，
//         * 但是该方法会将前端传入的blog对象中为null的属性也copy进去，
//         * 所以我们可以自定义方法将为null的属性过滤掉再进行copy操作。
//         */
//        Blog blogOld = blogDao.getBlog(blog.getId());
//        BeanUtils.copyProperties(blog, blogOld, MyBeanUtils.getNullPropertyNames(blog));\
        blog.setUpdateTime(new Date());
        return blogDao.updateBlog(blog);
    }

    @Override
    public int deleteBlog(Long id) {
        return blogDao.deleteBlog(id);
    }

    @Override
    public List<Blog> getRecommendedBlogs() {
        return blogDao.getRecommendedBlogs();
    }

    @Override
    public List<FirstPageBlog> getAllBlogsByQuery(String query) {
        return blogDao.getAllBlogsByQuery(query);
    }
}
