package com.carrot.service;

import com.carrot.entity.Comment;

import java.util.List;

/**
 * @author Carrot
 * @create 2022/2/28 - 19:39
 */
public interface CommentService {

    List<Comment> listCommentByBlogId(Long blogId);

    int saveComment(Comment comment);

    void deleteComment(Long id);

}
