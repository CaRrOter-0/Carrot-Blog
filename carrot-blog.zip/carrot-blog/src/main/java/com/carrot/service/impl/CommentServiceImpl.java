package com.carrot.service.impl;

import com.carrot.dao.CommentDao;
import com.carrot.entity.Comment;
import com.carrot.service.BlogService;
import com.carrot.service.CommentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * @author Carrot
 * @create 2022/2/28 - 19:41
 */
@Service
public class CommentServiceImpl implements CommentService {

    @Autowired
    private CommentDao commentDao;

    private List<Comment> tempReplys = new ArrayList<>();

    @Override
    public List<Comment> listCommentByBlogId(Long blogId) {
        List<Comment> comments = commentDao.findByBlogIdParentIdNull(blogId, Long.parseLong("-1"));
        for (Comment comment : comments) {
            Long id = comment.getId();
            String nickname = comment.getNickname();
            //找出所有子评论
            List<Comment> childComments = commentDao.findByBlogIdParentIdNotNull(blogId, id);
            combineChildren(blogId, childComments, nickname);

            //将子评论的数据传入comment中
            comment.setReplyComments(tempReplys);
            tempReplys = new ArrayList<>();
        }
        return comments;
    }

    /**
     * 找出一、二级子评论
     * @param blogId
     * @param childComments
     * @param parentNickname
     */
    private void combineChildren(Long blogId, List<Comment> childComments, String parentNickname) {
        //判断是否有一级子评论
        if (childComments.size() > 0) {
            for (Comment childComment : childComments) {
                //将childComment添加到tempReplys中
                childComment.setParentNickname(parentNickname);
                tempReplys.add(childComment);

                //找出所有的二级评论
                recursively(blogId, childComment.getId(), childComment.getNickname());
            }
        }
    }

    /**
     * 通过递归找出所有二级子评论
     * @param blogId
     * @param childId
     * @param parentNickname
     */
    private void recursively(Long blogId, Long childId, String parentNickname) {
        //通过父级评论的id找出子级评论
        List<Comment> replyComments = commentDao.findByBlogIdParentIdNotNull(blogId, childId);

        if (replyComments.size() > 0) {
            for (Comment replyComment : replyComments) {
                //将childComment添加到tempReplys中
                replyComment.setParentNickname(parentNickname);
                tempReplys.add(replyComment);
                //找出所有的子级评论
                recursively(blogId, replyComment.getId(), replyComment.getNickname());
            }
        }

    }

    @Override
    public int saveComment(Comment comment) {
        comment.setCreateTime(new Date());
        return commentDao.saveComment(comment);
    }

    /**
     * 删除评论
     * @param id
     */
    @Override
    public void deleteComment(Long id) {
        commentDao.deleteComment(id);
    }

}
