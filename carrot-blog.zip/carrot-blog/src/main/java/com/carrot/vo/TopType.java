package com.carrot.vo;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * @author Carrot
 * @create 2022/2/26 - 21:14
 */
@Data
@ToString
@NoArgsConstructor
public class TopType {

    private Long id;

    private String name;

    private Integer counts;

}
