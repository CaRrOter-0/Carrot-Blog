package com.carrot.dao;

import com.carrot.entity.Blog;
import com.carrot.vo.BlogQuery;
import com.carrot.vo.DetailedBlog;
import com.carrot.vo.FirstPageBlog;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author Carrot
 * @create 2022/1/23 - 17:01
 */
@Mapper
@Repository
public interface BlogDao {

    Blog getBlog(Long id);

    DetailedBlog getDetailedBlogById(Long id);

    List<Blog> listBlog();

    List<BlogQuery> getAllBlogQuery();

    List<BlogQuery> getAllBlogBySearch(BlogQuery blogQuery);

    int saveBlog(Blog blog);

    int updateBlog(Blog blog);

    int deleteBlog(Long id);

    List<FirstPageBlog> listFirstPageBlog();

    List<Blog> getRecommendedBlogs();

    List<FirstPageBlog> getAllBlogsByQuery(String query);

    void updateViews(Long id);

    List<FirstPageBlog> getFirstPageBlogByTypeId(Long typeId);
}
