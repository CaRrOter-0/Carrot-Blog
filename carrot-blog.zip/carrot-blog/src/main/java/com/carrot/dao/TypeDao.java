package com.carrot.dao;

import com.carrot.entity.Type;
import com.carrot.vo.TopType;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author Carrot
 * @create 2022/1/22 - 13:24
 */
@Mapper
@Repository
public interface TypeDao {
    int saveType(Type type);

    Type getType(Long id);

    List<Type> listAllType();

    List<TopType> listAllBlogByType();

    int updateType(Type type);

    void deleteType(Long id);

    Type getTypeByName(String name);
}
