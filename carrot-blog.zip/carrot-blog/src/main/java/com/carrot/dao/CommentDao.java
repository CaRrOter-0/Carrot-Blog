package com.carrot.dao;

import com.carrot.entity.Comment;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @author Carrot
 * @create 2022/2/28 - 19:42
 */
@Mapper
@Repository
public interface CommentDao {

    List<Comment> findByBlogIdParentIdNull(@Param("blogId") Long blogId, @Param("blogParentId") Long blogParentId);

    int saveComment(Comment comment);

    /**
     * 查询一级回复
     * @param blogId
     * @param id
     * @return
     */
    List<Comment> findByBlogIdParentIdNotNull(@Param("blogId") Long blogId, @Param("id") Long id);

    void deleteComment(Long id);
}
