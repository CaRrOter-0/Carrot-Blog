package com.carrot.dao;

import com.carrot.entity.User;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

/**
 * @author Carrot
 * @create 2022/1/20 - 15:19
 */
@Mapper
@Repository
public interface UserDao{
    User findByUsernameAndPassword(@Param("username") String username, @Param("password") String password);
}
