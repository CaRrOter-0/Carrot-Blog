package com.carrot.aspect;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.ToString;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import javax.servlet.http.HttpServletRequest;

/**
 * Spring 支持两种方法匹配器：静态方法匹配器和动态方法匹配器。
 * 所谓静态方法匹配器，仅对方法名签名（包括方法名和入参类型及顺序）进行匹配；
 * 而动态方法匹配器会在运行期检查方法入参的值。静态匹配仅会判别一次，
 * 而动态匹配因为每次调用方法的入参都可能不一样，所以每次调用方法都必须判断，
 * 因此，动态匹配对性能的影响很大。一般情况下，动态匹配不常使用。
 * 方法匹配器的类型由 isRuntime() 方法的返回值决定，返回 false 表示是静态方法匹配器，
 * 返回 true 表示是动态方法匹配器。
 *
 * 注解@Aspect：
 * 有了这个才可以做一些切面的操作
 * 注解@Component：
 * 加了这个springboot才能扫描到它
 *
 * @author Carrot
 * @create 2022/1/18 - 21:49
 */
@Aspect
@Component
public class LogAspect {

    @Autowired
    private  HttpServletRequest request;

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    /**
     * 定义一个切面
     * <p>
     * 注解@Pointcut():
     * 声明是一个切面
     * execution():
     * 用来规定需要拦截的是哪些类
     * <p>
     * 第一个*:
         * 是指返回值，而不是访问权限，范围权限默认是可以不写的，但返回值必须写
     * com.carrot.web.*.*(..):
         * 表示web目录下的所有类的所有方法
     */
    @Pointcut("execution(* com.carrot.web.*.*(..))")
    public void log() {}

    /**
     * 注解@Before("log()"):
     *      前置通知
     *      括号里面传递 的就是切面方法，
     *      意义就是doBefore会在执行切面方法前执行
     */
    @Before("log()")
    public void doBefore(JoinPoint joinPoint) {
        /**
            获取请求
                这是获取request请求的方式之一——通过RequestContextHolder获取
            当然还有最常见的获取请求方式就是通过注解@Autowired获取
         */
//        ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
//        HttpServletRequest request = attributes.getRequest();

        String url = request.getRequestURL().toString();
        String ip = request.getRemoteAddr();
        String classMethod = joinPoint.getSignature().getDeclaringTypeName() + "." + joinPoint.getSignature().getName();
        Object[] args = joinPoint.getArgs();
        RequestLog requestLog = new RequestLog(url, ip, classMethod, args);

        logger.info("request : {}", requestLog);

//        logger.info("-------------doBefore--------------");
    }

    /**
     * 注解After("log()")
     *      用法和前置通知一样，
     *      最终通知，相当于finally
     */
    @After("log()")
    public void doAfter() {
        logger.info("-----------doAfter-------------");
    }

    /**
     * 注解@AfterReturning():
     *      声明该方法能返回日志内容
     * returning = "result":
     *      表示返回的内容为result这个Object对象
     * pointcut = "log()":
     *      表示对应的切面方法是log()
     *
     * @param result ： 日志内容
     */
    @AfterReturning(returning = "result", pointcut = "log()")
    public void doAfterReturn(Object result) {
        logger.info("Result : {}" , result);
    }

    /**
     * 定义一个类来获取日志信息
     */
    @ToString
    @AllArgsConstructor
    private class RequestLog {
        private String url;
        private String ip;
        private String classMethod;
        private Object[] args;
    }
}
