package com.carrot;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * 如果你想要通过该异常使页面跳转到404.html上
 * 你还要指定返回的状态码
 * <p>
 * 因此通过@ResponseStatus(HttpStatus.NOT_FOUND)注解
 * 系统会将这个异常状态作为资源找不到的状态
 *
 * @author Carrot
 * @create 2022/1/18 - 21:24
 */
@ResponseStatus(HttpStatus.NOT_FOUND)
public class NotFoundException extends RuntimeException {
    public NotFoundException() {
    }

    public NotFoundException(String message) {
        super(message);
    }

    public NotFoundException(String message, Throwable cause) {
        super(message, cause);
    }
}
