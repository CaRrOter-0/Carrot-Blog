package com.carrot.Interceptor;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

/**
 * @author Carrot
 * @create 2022/1/21 - 17:20
 */
@Configuration
public class WebConfig implements WebMvcConfigurer {

    /**
     * .addInterceptor(new LoginInterceptor())：将拦截的器加进来
     * .addPathPatterns("/admin/**")：将拦截的目标页面加进去
     *
     * .excludePathPatterns("/admin","/admin/login","/css/**","/image/**","/js/**","/lib/**")：
     *          将成功登录页面的情况排除过滤掉，包括静态资源（css，js，lib等）
     *
     * @param registry 定义好的拦截网
     */
    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(new LoginInterceptor())
                    .addPathPatterns("/admin/**")
                    .excludePathPatterns("/admin","/admin/login","/css/**","/image/**","/js/**","/lib/**");
    }
}
