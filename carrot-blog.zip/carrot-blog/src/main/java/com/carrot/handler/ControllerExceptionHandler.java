package com.carrot.handler;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.annotation.AnnotationUtils;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;

/**
 * 因为springboot遇到错误后会自动拦截
 * 并跳转到templates.error文件夹里面的400.html和500.html
 *
 * 但如果想要自定义创建错误页面error.html的话，
 * springboot是没法自动拦截我们自定义的错误并跳转error.html的，
 * 这个时候我们应该要自定义创建拦截器来拦截所有的异常并进行统一逻辑的处理和判断
 *
 * 注解@ControllerAdvice：可以拦截所有标有@Controller注解的类的错误
 *
 * @author Carrot
 * @create 2022/1/18 - 20:33
 */
@ControllerAdvice
public class ControllerExceptionHandler {

    /**
     * Logger要选择org.slf4j路径的
     *
     * 这个是可以作为日志记录
     */
    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    /**
     * ModelAndView:
         * 可以控制一个返回页面
         * 并且加一些后台输出的一些前端信息
     * <p>
     * HttpServletRequest:
         * 我们希望能访问的哪个路径出现了异常
         * 这个时候就可以从request里获取访问的url
     * <p>
     * 注解@ExceptionHandler(Exception.class):
         * 可以标识这个方法是可以用来做异常处理的
         * Exception.class表示只要是Exception及其子类的都可以做异常处理
     */
    @ExceptionHandler(Exception.class)
    public ModelAndView exceptionHandler(HttpServletRequest request, Exception e) throws Exception {
        //记录异常信息
        logger.error("Request URL : {}, Exception : {}", request.getRequestURL(), e);

        //取消拦截未找到资源的错误信息，让springboot自己去拦截NOT_FOUND异常并跳转到404页面
        if (AnnotationUtils.findAnnotation(e.getClass(), ResponseStatus.class) != null) {
            throw e;
        }

        //创建ModelAndView对象，添加url和异常信息
        ModelAndView mv = new ModelAndView();
        mv.addObject("url", request.getRequestURL());
        mv.addObject("exception", e);
        //选择想要返回的页面
        mv.setViewName("error/error");
        return mv;
    }
}
